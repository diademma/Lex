# --- START OF FILE config.py ---

import os

# --- КЛЮЧИ И ТОКЕНЫ ТЕЛЕГРАМ ---
# Приоритетно считываем из переменных окружения (полезно для Alwaysdata / GitHub),
# но оставляем ваши текущие значения по умолчанию.
BOT_TOKEN = os.getenv("BOT_TOKEN", "8617655235:AAEydphMLqqTy115EBP3jNTxhgCiNgDSRf0")
OWNER_ID = int(os.getenv("OWNER_ID", "5421909121"))

# ПРИМЕЧАНИЕ: API_ID, API_HASH и STRING_SESSION удалены, так как юзербот отключен.

# --- ПУТИ К ПАПКАМ ---
MODULES_DIR = "modules"
UPDATES_DIR = "updates"
BACKUP_DIR = "backups"
MICRO_BACKUP_DIR = "backups/micro"

for folder in [MODULES_DIR, UPDATES_DIR, BACKUP_DIR, MICRO_BACKUP_DIR]:
    os.makedirs(folder, exist_ok=True)

# --- НАСТРОЙКИ СИСТЕМЫ ---
DB_NAME = "lex_memory.db"


# --- ВСПОМОГАТЕЛЬНАЯ ФУНКЦИЯ ДЛЯ КЛЮЧЕЙ ИИ ---
def _get_api_keys(provider_name, default_keys):
    """
    Позволяет переопределять списки ключей через переменные окружения,
    например: DEEPSEEK_KEYS="key1,key2"
    """
    env_val = os.getenv(f"{provider_name.upper()}_KEYS")
    if env_val:
        return [k.strip() for k in env_val.split(",") if k.strip()]
    return default_keys


# --- ИИ АРСЕНАЛ (БЕССМЕРТНЫЙ ПУЛ КЛЮЧЕЙ) ---
API_KEYS = {
    "groq": _get_api_keys("groq", [
        "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",
        "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",
        "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",
        "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",
    ]),
    "mistral": _get_api_keys("mistral", [
        "wWOjl0alkJayMVe8s5OSeXGXMOSXAxlL",
        "I15dT8r0T16xVfE4MajeMqkyf8wh4H4b",
        "0p3ljY7wmKDO4ZYZUqjmT3zCzFbUVOy8",
    ]),
    "cohere": _get_api_keys("cohere", [
        "c57p3zLgZaHOGLbW8xfI4tgJfJBRqhbb3JY3nY0z",
        "raCo683CA5sMU5ilLimJx5WE5f4KjskSZjnMUqlf",
        "1N2YFigntPg3RD8KVM8hkfMOFTtuuzNFOaAUz59q",
        "Ca2l41Ytha7oHsd2bZGH9kJqWngy9mKJLdOu8PlU",
    ]),
    "github": _get_api_keys("github", [
        "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",
        "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",
        "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",
    ]),
    "deepseek": _get_api_keys("deepseek", [
        "sk-e78050c779e648bd8fd00d7a01cbebbb",
        "sk-00d85e76cc3f40a28bb74cdcbc39d1e3",
        "sk-32d6490e3f6d4c9a9c0cd5a25d641705",
        "sk-a34966b47161478ba44d3267c46b580f",
    ]),
    "zai": _get_api_keys("zai", [
        "fe4bced20aa24ea18829ee6806f14ceb.YXRtIHCHzrGWWO3U",
        "3b74e6a99325492982e2620a368e2014.xyPJ3LizCtjEJVN7",
        "f58acefcbb6f497d9c5b62fdebbd185d.6ZlzNMnsQqAV81Re",
    ]),
    "openrouter": _get_api_keys("openrouter", [
        "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",
        "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",
        "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",
    ]),
    "huggingface": _get_api_keys("huggingface", [
        "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",
        "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",
        "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",
        "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",
    ]),
    "together": _get_api_keys("together", [
        "tgp_v1_baLy2Pn80ZcbZAgmUVzgqBa3xF7XIKulWAQay7FVdxs",
        "tgp_v1_DHwq4YgjfInnDWb7-0dPFovkW3d2iJlQiRdimejCpew",
        "tgp_v1_qjJ6uIa0zDYAWNB15pn5In39iB6B6_HpNr8h_goI9EM",
    ]),
}