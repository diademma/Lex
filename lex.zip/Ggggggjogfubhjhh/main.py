# --- START OF FILE main.py ---

import asyncio
import logging
import sys
import os
import importlib.util
import config
import database

# 1. Инициализация базы данных
database.init_db()

# 2. Подключение безопасного режима (Safe Mode)
import safe_mode

# 3. Импорт компонентов ядра (без Тень/Telethon)
try:
    from aiogram_face import dp, bot
    from reposter_worker import reposter_worker
except Exception as e:
    logging.critical(f"Ошибка при импорте модулей ядра: {e}")
    raise

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("lex.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)


async def main():
    # Динамическая загрузка плагинов
    modules = database.get_all_modules()
    for mod in modules:
        if mod["enabled"]:
            mod_path = os.path.join(config.MODULES_DIR, mod["name"])
            if os.path.exists(mod_path):
                try:
                    spec   = importlib.util.spec_from_file_location(mod["name"][:-3], mod_path)
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    if hasattr(module, "router"):
                        dp.include_router(module.router)
                        logging.info(f"✅ Плагин {mod['name']} загружен.")
                except Exception as e:
                    logging.error(f"❌ Ошибка загрузки плагина {mod['name']}: {e}")

    logging.info("🚀 ЗАПУСК ЯДРА LEX (чистый Bot API)...")

    try:
        await bot.send_message(
            config.OWNER_ID,
            "✅ <b>Система LEX успешно перезагружена!</b>",
            parse_mode="HTML",
        )
    except Exception as e:
        logging.error(f"Уведомление о запуске не отправлено: {e}")

    # Запускаем только 2 корутины параллельно:
    # - dp.start_polling     → aiogram (обработка команд, кнопок и меню)
    # - reposter_worker(bot) → Репостер (сборщик постов t.me/s и их отправка)
    await asyncio.gather(
        dp.start_polling(bot),
        reposter_worker(bot),
    )


if __name__ == "__main__":
    try:
        if sys.platform == "win32":
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logging.info("Система LEX остановлена.")