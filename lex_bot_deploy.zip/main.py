import asyncio
import logging
import sys
import os
import importlib.util

# ── 1. ПЕРВЫМ ДЕЛОМ — БД И SAFE MODE ─────────────────────────────────────────
import database
database.init_db()

import safe_mode  # устанавливает sys.excepthook

# ── 2. ЛОГИРОВАНИЕ ────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("lex.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)

# ── 3. ЯДРО ───────────────────────────────────────────────────────────────────
from aiogram_face import dp, bot
from telethon_shadow import client, shadow_worker
from reposter_worker import reposter_worker
import config


async def main():
    # Подключаем Telethon (юзербот) если сессия задана
    if client is not None:
        logging.info("Подключение Тени к серверам Telegram...")
        try:
            await client.connect()
        except Exception as e:
            logging.error(f"Не удалось подключить юзербот: {e}")

    # ── Динамическая загрузка включённых плагинов ─────────────────────────────
    modules = database.get_all_modules()
    for mod in modules:
        if mod["enabled"]:
            mod_path = os.path.join(config.MODULES_DIR, mod["name"])
            if os.path.exists(mod_path):
                try:
                    spec   = importlib.util.spec_from_file_location(mod["name"][:-3], mod_path)
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    if hasattr(module, "router"):
                        dp.include_router(module.router)
                        logging.info(f"✅ Плагин {mod['name']} загружен.")
                except Exception as e:
                    logging.error(f"❌ Ошибка загрузки плагина {mod['name']}: {e}")

    logging.info("🚀 ЗАПУСК ЯДРА LEX...")

    try:
        await bot.send_message(
            config.OWNER_ID,
            "✅ <b>Система LEX успешно перезагружена!</b>",
            parse_mode="HTML",
        )
    except Exception as e:
        logging.error(f"Уведомление о запуске не отправлено: {e}")

    # ── Запускаем корутины параллельно ────────────────────────────────────────
    tasks = [
        dp.start_polling(bot),
        shadow_worker(),
        reposter_worker(bot),
    ]
    # client.run_until_disconnected() добавляем только если Telethon активен
    if client is not None:
        tasks.append(client.run_until_disconnected())

    await asyncio.gather(*tasks)


if __name__ == "__main__":
    try:
        if sys.platform == "win32":
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logging.info("Система LEX остановлена.")
