#!/bin/bash
# LEX v2 — быстрый деплой на AlwaysData
# Использование: bash setup.sh

set -e

echo "=== LEX v2: создаю окружение ==="

python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip -q
pip install -r requirements.txt -q

echo "=== Готово! Запусти бота: ==="
echo "    source venv/bin/activate && python3 main.py"
